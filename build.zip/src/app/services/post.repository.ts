


export default class PostRepository{


  

}