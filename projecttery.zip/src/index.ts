import Application  from "./app/app";
new Application().startServer();

